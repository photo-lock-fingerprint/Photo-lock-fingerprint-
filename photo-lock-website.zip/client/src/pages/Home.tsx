import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Download, Lock, Fingerprint, Eye, Zap } from "lucide-react";

/**
 * Home Page
 * Design: Dark glassmorphism with purple-blue gradient accents
 * - Hero section with app showcase
 * - Feature highlights with icons
 * - Screenshots grid
 * - Call-to-action for Google Play Store
 */
export default function Home() {
  const features = [
    {
      icon: Fingerprint,
      title: "Fingerprint Lock",
      description: "Secure access with biometric authentication",
    },
    {
      icon: Lock,
      title: "PIN Protection",
      description: "Additional layer of security with custom PIN",
    },
    {
      icon: Eye,
      title: "Hide Photos & Videos",
      description: "Keep your private memories completely hidden",
    },
    {
      icon: Zap,
      title: "Offline & Secure",
      description: "Works completely offline, no data collection",
    },
  ];

  const screenshots = [
    { id: 1, alt: "App Lock Screen" },
    { id: 2, alt: "Gallery View" },
    { id: 3, alt: "Settings Screen" },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-background via-background to-background">
      <Navigation />

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-16 md:py-24 flex flex-col md:flex-row items-center gap-12">
        {/* Left Content */}
        <div className="flex-1 space-y-6">
          <div className="space-y-4">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
              <span className="gradient-text">Secure Your Private</span>
              <br />
              <span className="text-foreground">Photos & Videos</span>
            </h1>
            <p className="text-lg text-foreground/70 max-w-xl">
              Photo Lock Fingerprint provides military-grade security for your most private moments. Fingerprint lock, PIN protection, and complete offline functionality.
            </p>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 pt-4">
            <a
              href="https://play.google.com/store/apps/details?id=com.kgnsolution.photolock"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-gradient inline-flex items-center justify-center gap-2"
            >
              <Download size={20} />
              Get it on Google Play
            </a>
            <button className="btn-gradient-outline inline-flex items-center justify-center gap-2">
              Learn More
            </button>
          </div>

          {/* Version Info */}
          <div className="pt-4">
            <p className="text-sm text-foreground/50">
              <span className="inline-block px-3 py-1 rounded-full glass-light">
                v1.0.0
              </span>
            </p>
          </div>
        </div>

        {/* Right - App Icon */}
        <div className="flex-1 flex justify-center">
          <div className="relative">
            {/* Glow effect */}
            <div className="absolute inset-0 bg-gradient-to-br from-purple-500 to-blue-500 rounded-3xl blur-3xl opacity-20 animate-pulse"></div>
            {/* App Icon */}
            <div className="relative w-48 h-48 md:w-64 md:h-64 rounded-3xl glass-accent flex items-center justify-center">
              <div className="text-center">
                <div className="text-8xl mb-4">🔒</div>
                <p className="text-sm font-semibold text-foreground/70">Photo Lock</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-16 md:py-24">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="gradient-text">Key Features</span>
          </h2>
          <p className="text-foreground/60 max-w-2xl mx-auto">
            Everything you need to keep your photos secure and private
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <div key={idx} className="glass rounded-xl p-6 hover:glass-accent transition-all duration-300 group">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-purple-500/20 to-blue-500/20 flex items-center justify-center mb-4 group-hover:from-purple-500/30 group-hover:to-blue-500/30 transition-all">
                  <Icon className="text-purple-400" size={24} />
                </div>
                <h3 className="font-semibold text-foreground mb-2">{feature.title}</h3>
                <p className="text-sm text-foreground/60">{feature.description}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Screenshots Section */}
      <section className="container mx-auto px-4 py-16 md:py-24">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="gradient-text">App Screenshots</span>
          </h2>
          <p className="text-foreground/60">
            See Photo Lock in action
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {screenshots.map((screenshot) => (
            <div
              key={screenshot.id}
              className="glass rounded-xl overflow-hidden aspect-[9/16] flex items-center justify-center"
            >
              {/* Replace with Play Store screenshot */}
              <div className="w-full h-full bg-gradient-to-br from-purple-500/10 to-blue-500/10 flex items-center justify-center">
                <div className="text-center">
                  <p className="text-foreground/50 text-sm">
                    Replace with Play Store screenshot
                  </p>
                  <p className="text-foreground/30 text-xs mt-2">
                    screenshot{screenshot.id}.png
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="container mx-auto px-4 py-16 md:py-24">
        <div className="glass-accent rounded-2xl p-8 md:p-12 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Secure Your Photos?
          </h2>
          <p className="text-foreground/70 mb-8 max-w-2xl mx-auto">
            Download Photo Lock Fingerprint today and experience military-grade security for your private moments.
          </p>
          <a
            href="https://play.google.com/store/apps/details?id=com.kgnsolution.photolock"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-gradient inline-flex items-center justify-center gap-2"
          >
            <Download size={20} />
            Download Now
          </a>
        </div>
      </section>

      <Footer />
    </div>
  );
}
