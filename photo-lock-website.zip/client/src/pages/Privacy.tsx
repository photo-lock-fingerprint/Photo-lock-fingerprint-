import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Shield, Lock, Eye, Server } from "lucide-react";

/**
 * Privacy Policy Page
 * Design: Dark glassmorphism with structured content layout
 * - Comprehensive privacy policy for Google Play Store compliance
 * - Clear sections with icons
 * - Last updated timestamp
 */
export default function Privacy() {
  const sections = [
    {
      icon: Shield,
      title: "Information We DO NOT Collect",
      id: "no-collection",
    },
    {
      icon: Lock,
      title: "Security Measures",
      id: "security",
    },
    {
      icon: Eye,
      title: "Your Rights",
      id: "rights",
    },
    {
      icon: Server,
      title: "Compliance",
      id: "compliance",
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-background via-background to-background">
      <Navigation />

      {/* Header */}
      <section className="container mx-auto px-4 py-12 md:py-16">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">
          <span className="gradient-text">Privacy Policy</span>
        </h1>
        <p className="text-foreground/60">
          Last Updated: January 2024
        </p>
      </section>

      {/* Quick Navigation */}
      <section className="container mx-auto px-4 mb-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {sections.map((section) => {
            const Icon = section.icon;
            return (
              <a
                key={section.id}
                href={`#${section.id}`}
                className="glass rounded-lg p-4 hover:glass-accent transition-all duration-300 group flex items-start gap-3"
              >
                <Icon className="text-purple-400 flex-shrink-0 mt-1" size={20} />
                <span className="text-sm font-medium text-foreground/80 group-hover:text-foreground">
                  {section.title}
                </span>
              </a>
            );
          })}
        </div>
      </section>

      {/* Main Content */}
      <section className="container mx-auto px-4 pb-16">
        <div className="max-w-3xl mx-auto space-y-12">
          {/* Introduction */}
          <div className="glass rounded-xl p-8">
            <h2 className="text-2xl font-bold mb-4">Introduction</h2>
            <p className="text-foreground/70 mb-4">
              Welcome to Photo Vault ("we," "our," or "us"). We are committed to protecting your privacy. This Privacy Policy explains how we handle information in our Photo Vault mobile application.
            </p>
            <div className="glass-light rounded-lg p-4 border-l-4 border-purple-500">
              <p className="text-sm font-semibold text-foreground mb-2">Core Principle</p>
              <p className="text-sm text-foreground/70">
                Photo Vault is designed with privacy as the fundamental principle. The app works completely offline and collects zero data.
              </p>
            </div>
          </div>

          {/* No Data Collection */}
          <div id="no-collection" className="glass rounded-xl p-8 scroll-mt-20">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
              <Shield className="text-purple-400" />
              Information We DO NOT Collect
            </h2>
            <p className="text-foreground/70 mb-6">
              We want to be absolutely clear about what we do NOT collect:
            </p>
            <ul className="space-y-3">
              {[
                "No Personal Information: We don't collect names, email addresses, phone numbers, or any identifiable information",
                "No Photo Access: We don't access, view, analyze, or upload your photos",
                "No Internet Connection: The app has no internet permission and cannot transmit any data",
                "No Analytics: We don't collect usage statistics, crash reports, or any analytics",
                "No Location Data: We don't collect GPS or location information",
                "No Contacts: We don't access your contact list or social connections",
                "No Device Information: We don't collect device IDs, IMEI numbers, or hardware information",
              ].map((item, idx) => (
                <li key={idx} className="flex gap-3 text-foreground/70">
                  <span className="text-purple-400 font-bold flex-shrink-0">•</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Photo Handling */}
          <div className="glass rounded-xl p-8">
            <h2 className="text-2xl font-bold mb-6">How Your Photos Are Handled</h2>

            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-3">Storage Location</h3>
                <p className="text-foreground/70 mb-3">
                  All photos are stored locally on your device only in the app's private directory. Photos are never uploaded to:
                </p>
                <ul className="space-y-2 ml-4">
                  {[
                    "Our servers (we don't have any)",
                    "Cloud storage services",
                    "Third-party servers",
                    "Any external storage",
                  ].map((item, idx) => (
                    <li key={idx} className="flex gap-2 text-foreground/70">
                      <span className="text-blue-400">✓</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-3">Photo Deletion</h3>
                <p className="text-foreground/70 mb-3">
                  When you delete photos:
                </p>
                <ul className="space-y-2 ml-4">
                  {[
                    "Photos are permanently deleted from device storage",
                    "No copies are retained anywhere",
                    "No recovery is possible through the app",
                    "Standard Android file recovery tools might recover deleted files until overwritten",
                  ].map((item, idx) => (
                    <li key={idx} className="flex gap-2 text-foreground/70">
                      <span className="text-blue-400">✓</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Security */}
          <div id="security" className="glass rounded-xl p-8 scroll-mt-20">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
              <Lock className="text-purple-400" />
              Security Measures
            </h2>
            <p className="text-foreground/70 mb-6">
              We implement these security measures:
            </p>
            <ul className="space-y-3">
              {[
                "Photos stored in Android's sandboxed private storage",
                "PIN protection with SHA-256 hashing",
                "Biometric authentication using Android's secure APIs",
                "No network connectivity prevents remote access",
                "Photos encrypted at the device level",
              ].map((item, idx) => (
                <li key={idx} className="flex gap-3 text-foreground/70">
                  <span className="text-purple-400 font-bold flex-shrink-0">•</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
            <div className="glass-light rounded-lg p-4 mt-6 border-l-4 border-blue-500">
              <p className="text-sm text-foreground/70">
                <span className="font-semibold">Important:</span> While we implement security measures, no system is 100% secure. You should keep your device secure, remember your PIN, back up photos regularly, and keep your Android OS updated.
              </p>
            </div>
          </div>

          {/* Permissions */}
          <div className="glass rounded-xl p-8">
            <h2 className="text-2xl font-bold mb-6">Permissions Explained</h2>
            <p className="text-foreground/70 mb-6">
              Photo Vault uses minimal permissions:
            </p>
            <div className="space-y-3">
              {[
                { title: "No Internet Permission", desc: "The app cannot connect to the internet" },
                { title: "Biometric Permission", desc: "Only for fingerprint/face unlock (handled by Android OS)" },
                { title: "No Gallery Permission", desc: "Uses Android's Photo Picker API instead (doesn't need access to all photos)" },
              ].map((item, idx) => (
                <div key={idx} className="glass-light rounded-lg p-4">
                  <p className="font-semibold text-foreground mb-1">{item.title}</p>
                  <p className="text-sm text-foreground/70">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Third-Party Services */}
          <div className="glass rounded-xl p-8">
            <h2 className="text-2xl font-bold mb-6">Third-Party Services</h2>
            <p className="text-foreground/70 mb-6">
              Photo Vault does NOT use any third-party services:
            </p>
            <ul className="space-y-2">
              {[
                "No advertising networks",
                "No analytics services",
                "No crash reporting tools",
                "No cloud storage providers",
                "No social media integrations",
                "No payment processors (app is free)",
              ].map((item, idx) => (
                <li key={idx} className="flex gap-2 text-foreground/70">
                  <span className="text-red-400">✗</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Rights */}
          <div id="rights" className="glass rounded-xl p-8 scroll-mt-20">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
              <Eye className="text-purple-400" />
              Your Rights
            </h2>
            <p className="text-foreground/70 mb-6">
              Since we don't collect any data:
            </p>
            <div className="space-y-3">
              {[
                { title: "Right to Access", desc: "No data exists to access" },
                { title: "Right to Deletion", desc: "All data is on your device; delete within the app" },
                { title: "Right to Correction", desc: "Not applicable as no data is collected" },
                { title: "Right to Portability", desc: "Not applicable as no data is collected" },
              ].map((item, idx) => (
                <div key={idx} className="glass-light rounded-lg p-4">
                  <p className="font-semibold text-foreground mb-1">{item.title}</p>
                  <p className="text-sm text-foreground/70">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Compliance */}
          <div id="compliance" className="glass rounded-xl p-8 scroll-mt-20">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
              <Server className="text-purple-400" />
              Compliance
            </h2>
            <p className="text-foreground/70 mb-6">
              Photo Vault complies with:
            </p>
            <ul className="space-y-2">
              {[
                "Google Play Store policies",
                "Android privacy guidelines",
                "General Data Protection principles",
                "Children's Online Privacy Protection Act (COPPA)",
              ].map((item, idx) => (
                <li key={idx} className="flex gap-2 text-foreground/70">
                  <span className="text-green-400">✓</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div className="glass rounded-xl p-8">
            <h2 className="text-2xl font-bold mb-6">Contact Information</h2>
            <p className="text-foreground/70 mb-6">
              For privacy-related questions:
            </p>
            <div className="space-y-3">
              {[
                { label: "Email", value: "privacy@photovault.app" },
                { label: "Response Time", value: "We aim to respond within 48 hours" },
                { label: "Technical Support", value: "support@photovault.app" },
              ].map((item, idx) => (
                <div key={idx} className="flex gap-4">
                  <span className="font-semibold text-foreground/70 min-w-fit">{item.label}:</span>
                  <span className="text-foreground/70">{item.value}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Summary */}
          <div className="glass-accent rounded-xl p-8 border-l-4 border-blue-500">
            <p className="text-foreground/70 leading-relaxed">
              <span className="font-semibold text-foreground">Summary:</span> Photo Vault doesn't collect, store, or transmit any of your data. Your photos remain on your device, protected by PIN/fingerprint, and never leave your possession. By using Photo Vault, you acknowledge that you have read and understood this Privacy Policy.
            </p>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
