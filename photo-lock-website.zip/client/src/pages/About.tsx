import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Heart, Target, Zap, Users, CheckCircle } from "lucide-react";

/**
 * About Us Page
 * Design: Dark glassmorphism with mission-focused content
 * - Company mission and values
 * - Team credentials
 * - Feature comparison
 * - Contact information
 */
export default function About() {
  const principles = [
    {
      icon: Heart,
      title: "Privacy First",
      description:
        "Every feature is designed with privacy as the core principle. We don't collect data because we don't need to.",
    },
    {
      icon: Target,
      title: "Complete Transparency",
      description:
        "We're clear about what we do and don't do. No hidden terms, no data collection, no surprises.",
    },
    {
      icon: Zap,
      title: "Security Without Compromise",
      description:
        "Military-grade security with SHA-256 hashing, biometric authentication, and local storage only.",
    },
    {
      icon: Users,
      title: "Free Forever",
      description:
        "Privacy shouldn't cost money. Completely free with no hidden charges, subscriptions, or feature limitations.",
    },
  ];

  const features = [
    { name: "Internet Permission", photoLock: "❌", others: "✅" },
    { name: "Data Collection", photoLock: "❌", others: "✅" },
    { name: "Cloud Storage", photoLock: "❌", others: "✅" },
    { name: "Cost", photoLock: "✅ Free", others: "❌ Ads/Subs" },
    { name: "Transparency", photoLock: "✅ Clear", others: "❌ Hidden" },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-background via-background to-background">
      <Navigation />

      {/* Header */}
      <section className="container mx-auto px-4 py-12 md:py-16">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">
          <span className="gradient-text">About Photo Lock</span>
        </h1>
        <p className="text-lg text-foreground/60 max-w-2xl">
          Privacy is a fundamental human right, not a luxury. We're building technology that respects your data.
        </p>
      </section>

      {/* Mission Section */}
      <section className="container mx-auto px-4 py-12 md:py-16">
        <div className="glass rounded-2xl p-8 md:p-12">
          <h2 className="text-3xl font-bold mb-6">Our Mission</h2>
          <p className="text-lg text-foreground/70 leading-relaxed mb-6">
            At Photo Vault, we believe privacy is a fundamental human right, not a luxury. In today's digital world where personal data is constantly collected, tracked, and monetized, we offer a sanctuary for your private memories.
          </p>
          <p className="text-lg text-foreground/70 leading-relaxed">
            Our mission is simple: <span className="font-semibold text-foreground">Provide everyone with secure, private photo storage that respects your privacy and gives you complete control over your personal photos.</span>
          </p>
        </div>
      </section>

      {/* Why We Created It */}
      <section className="container mx-auto px-4 py-12 md:py-16">
        <h2 className="text-3xl font-bold mb-8">Why We Created Photo Lock</h2>
        <p className="text-foreground/70 mb-6 max-w-3xl">
          We created Photo Lock out of frustration with existing "secure" photo apps that:
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          {[
            "Require internet permissions",
            "Collect user data",
            "Show intrusive ads",
            "Store photos on their servers",
            "Charge monthly subscriptions for basic privacy",
            "Don't respect user autonomy",
          ].map((item, idx) => (
            <div key={idx} className="glass rounded-lg p-4 flex gap-3">
              <span className="text-red-400 font-bold flex-shrink-0">✗</span>
              <span className="text-foreground/70">{item}</span>
            </div>
          ))}
        </div>
        <div className="glass-accent rounded-lg p-6 border-l-4 border-blue-500">
          <p className="text-foreground/70">
            We asked: <span className="font-semibold text-foreground">"What if a photo vault actually respected privacy?"</span> The answer became Photo Lock.
          </p>
        </div>
      </section>

      {/* Core Principles */}
      <section className="container mx-auto px-4 py-12 md:py-16">
        <h2 className="text-3xl font-bold mb-8">Our Core Principles</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {principles.map((principle, idx) => {
            const Icon = principle.icon;
            return (
              <div key={idx} className="glass rounded-xl p-6 hover:glass-accent transition-all duration-300">
                <div className="flex gap-4">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-purple-500/20 to-blue-500/20 flex items-center justify-center flex-shrink-0">
                    <Icon className="text-purple-400" size={24} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground mb-2">{principle.title}</h3>
                    <p className="text-sm text-foreground/70">{principle.description}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* How It Works */}
      <section className="container mx-auto px-4 py-12 md:py-16">
        <h2 className="text-3xl font-bold mb-8">How Photo Lock Works</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {/* User Flow */}
          <div>
            <h3 className="text-xl font-semibold mb-6">For Users</h3>
            <div className="space-y-4">
              {[
                { num: "1", title: "Set Your PIN", desc: "Create a secure 6-digit PIN" },
                { num: "2", title: "Add Photos", desc: "Select photos using Android's secure Photo Picker" },
                { num: "3", title: "Photos Are Secured", desc: "Originals removed from public gallery" },
                { num: "4", title: "Access Anytime", desc: "Unlock with PIN or fingerprint" },
                { num: "5", title: "Recover When Needed", desc: "Restore photos to gallery with one tap" },
              ].map((step, idx) => (
                <div key={idx} className="flex gap-4">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center flex-shrink-0">
                    <span className="text-white text-sm font-bold">{step.num}</span>
                  </div>
                  <div>
                    <p className="font-semibold text-foreground">{step.title}</p>
                    <p className="text-sm text-foreground/60">{step.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Technical */}
          <div>
            <h3 className="text-xl font-semibold mb-6">Technical Architecture</h3>
            <div className="space-y-3">
              {[
                { label: "Platform", value: "Native Android (Kotlin/Java)" },
                { label: "Security", value: "SHA-256 hashing, Android Biometric API" },
                { label: "Storage", value: "Local device storage only" },
                { label: "Permissions", value: "Minimal - no internet, no gallery access" },
                { label: "Design", value: "Material Design 3 compliant" },
              ].map((item, idx) => (
                <div key={idx} className="glass rounded-lg p-4">
                  <p className="text-sm font-semibold text-foreground/70 mb-1">{item.label}</p>
                  <p className="text-foreground/70">{item.value}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Comparison */}
      <section className="container mx-auto px-4 py-12 md:py-16">
        <h2 className="text-3xl font-bold mb-8">What Makes Us Different</h2>
        <div className="glass rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/10">
                  <th className="px-6 py-4 text-left font-semibold text-foreground">Feature</th>
                  <th className="px-6 py-4 text-center font-semibold text-purple-400">Photo Lock</th>
                  <th className="px-6 py-4 text-center font-semibold text-foreground/60">Other Apps</th>
                </tr>
              </thead>
              <tbody>
                {features.map((feature, idx) => (
                  <tr key={idx} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="px-6 py-4 text-foreground">{feature.name}</td>
                    <td className="px-6 py-4 text-center text-green-400 font-semibold">
                      {feature.photoLock}
                    </td>
                    <td className="px-6 py-4 text-center text-foreground/60">
                      {feature.others}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="container mx-auto px-4 py-12 md:py-16">
        <h2 className="text-3xl font-bold mb-8">The Team Behind Photo Lock</h2>
        <div className="glass rounded-xl p-8">
          <p className="text-foreground/70 mb-6 leading-relaxed">
            We're a small team of privacy-conscious developers who believe technology should protect users, not exploit them. Based in India, we understand the importance of digital privacy in today's connected world.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div className="glass-light rounded-lg p-6">
              <h3 className="font-semibold text-foreground mb-4">Our Credentials</h3>
              <ul className="space-y-2">
                {[
                  "5+ years in Android development",
                  "Experience in security and cryptography",
                  "Passion for privacy-focused software",
                  "Commitment to ethical technology",
                ].map((item, idx) => (
                  <li key={idx} className="flex gap-2 text-foreground/70">
                    <CheckCircle size={16} className="text-green-400 flex-shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="glass-light rounded-lg p-6">
              <h3 className="font-semibold text-foreground mb-4">Our Vision</h3>
              <p className="text-foreground/70 leading-relaxed">
                We envision a world where privacy is the default, not an option. Where users control their data completely, technology serves people, and security is accessible to everyone.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact */}
      <section className="container mx-auto px-4 py-12 md:py-16">
        <h2 className="text-3xl font-bold mb-8">Get In Touch</h2>
        <div className="glass-accent rounded-xl p-8">
          <p className="text-foreground/70 mb-8">
            We'd love to hear from you. Whether you have questions, suggestions, or feedback, reach out to us:
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { title: "Support", email: "support@photovault.app", desc: "Technical issues and help" },
              { title: "Feedback", email: "feedback@photovault.app", desc: "Feature requests and suggestions" },
              { title: "Privacy", email: "privacy@photovault.app", desc: "Privacy-related questions" },
            ].map((contact, idx) => (
              <a
                key={idx}
                href={`mailto:${contact.email}`}
                className="glass rounded-lg p-4 hover:glass-accent transition-all duration-300 group"
              >
                <p className="font-semibold text-foreground mb-1 group-hover:text-purple-400 transition-colors">
                  {contact.title}
                </p>
                <p className="text-sm text-foreground/60 mb-2">{contact.email}</p>
                <p className="text-xs text-foreground/50">{contact.desc}</p>
              </a>
            ))}
          </div>
          <p className="text-sm text-foreground/50 mt-6 text-center">
            Response Time: We aim to respond within 24-48 hours
          </p>
        </div>
      </section>

      {/* Final Message */}
      <section className="container mx-auto px-4 py-12 md:py-16">
        <div className="glass rounded-2xl p-8 md:p-12 text-center">
          <h2 className="text-3xl font-bold mb-4">
            <span className="gradient-text">Privacy Matters</span>
          </h2>
          <p className="text-lg text-foreground/70 max-w-2xl mx-auto leading-relaxed">
            Photo Lock is more than just an app - it's a statement. A statement that privacy matters, that users deserve control, and that technology can be both powerful and respectful.
          </p>
          <p className="text-foreground/60 mt-6">
            Thank you for choosing Photo Lock. Your trust is our greatest reward.
          </p>
        </div>
      </section>

      <Footer />
    </div>
  );
}
