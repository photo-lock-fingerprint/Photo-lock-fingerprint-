import { Link } from "wouter";

/**
 * Footer Component
 * Design: Dark glassmorphism footer with contact information
 * - Consistent branding across pages
 * - Quick links and contact details
 * - Professional appearance
 */
export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="glass border-t border-opacity-20 mt-20">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* Brand Section */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center">
                <span className="text-white font-bold">🔒</span>
              </div>
              <span className="font-bold gradient-text">Photo Lock</span>
            </div>
            <p className="text-sm text-foreground/60">
              Secure your private photos & videos with fingerprint protection.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4 text-foreground">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/">
                  <a className="text-sm text-foreground/60 hover:text-foreground transition-colors">
                    Home
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/about">
                  <a className="text-sm text-foreground/60 hover:text-foreground transition-colors">
                    About Us
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/privacy">
                  <a className="text-sm text-foreground/60 hover:text-foreground transition-colors">
                    Privacy Policy
                  </a>
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Section */}
          <div>
            <h4 className="font-semibold mb-4 text-foreground">Contact</h4>
            <ul className="space-y-2 text-sm text-foreground/60">
              <li>
                <a
                  href="mailto:support@photovault.app"
                  className="hover:text-foreground transition-colors"
                >
                  Support: support@photovault.app
                </a>
              </li>
              <li>
                <a
                  href="mailto:privacy@photovault.app"
                  className="hover:text-foreground transition-colors"
                >
                  Privacy: privacy@photovault.app
                </a>
              </li>
              <li>
                <a
                  href="mailto:feedback@photovault.app"
                  className="hover:text-foreground transition-colors"
                >
                  Feedback: feedback@photovault.app
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-white/10 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-foreground/50">
              © {currentYear} Photo Lock Fingerprint. All rights reserved.
            </p>
            <p className="text-sm text-foreground/50">
              Developed by <span className="font-semibold">Kgn Solution</span>
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
