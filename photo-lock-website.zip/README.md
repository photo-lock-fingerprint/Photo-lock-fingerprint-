# Photo Lock Fingerprint - Website

A modern, dark glassmorphism website for the **Photo Lock Fingerprint** Android application, developed by **Kgn Solution**. Fully compliant with Google Play Store requirements.

## 🎯 Overview

This website serves as the official landing page and information hub for the Photo Lock Fingerprint app. It includes:

- **Home Page** - App showcase with features and screenshots
- **Privacy Policy** - Comprehensive privacy policy for Google Play Store compliance
- **About Us** - Company mission, values, and team information

## ✨ Design Features

- **Dark Glassmorphism UI** - Modern blur effects with transparent cards
- **Purple & Blue Gradient** - Professional security-focused color scheme
- **Mobile-First Responsive** - Optimized for all device sizes
- **Fast Loading** - HTML + CSS only, no heavy frameworks
- **Accessibility** - Semantic HTML and keyboard navigation
- **Professional Typography** - Sora and Space Mono fonts from Google Fonts

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ 
- pnpm (recommended) or npm

### Installation

```bash
# Install dependencies
pnpm install

# Start development server
pnpm dev

# Build for production
pnpm build

# Preview production build
pnpm preview
```

The development server will start at `http://localhost:3000`

## 📁 Project Structure

```
photo-lock-website/
├── client/
│   ├── public/
│   │   └── screenshots/          ← Add your app screenshots here
│   ├── src/
│   │   ├── components/
│   │   │   ├── Navigation.tsx    ← Header with navigation
│   │   │   └── Footer.tsx        ← Footer with contact info
│   │   ├── pages/
│   │   │   ├── Home.tsx          ← Home page (app showcase)
│   │   │   ├── Privacy.tsx       ← Privacy Policy page
│   │   │   ├── About.tsx         ← About Us page
│   │   │   └── NotFound.tsx      ← 404 page
│   │   ├── App.tsx               ← Main app component with routing
│   │   ├── index.css             ← Global styles & design tokens
│   │   └── main.tsx              ← React entry point
│   └── index.html                ← HTML template
├── server/
│   └── index.ts                  ← Express server (static serving)
├── ASSETS_GUIDE.md               ← Asset replacement guide
├── README.md                     ← This file
└── package.json

```

## 🎨 Design System

### Color Palette
- **Primary Gradient:** Purple (#8b5cf6) → Blue (#3b82f6)
- **Background:** Dark Navy (#0a0e27)
- **Glass Effect:** RGBA(30, 27, 75, 0.4) with backdrop blur
- **Text Primary:** Light (#e8e9f3)
- **Accent:** Blue (#3b82f6)

### Typography
- **Display:** Sora (400, 500, 600, 700)
- **Monospace:** Space Mono (400, 700)

### Components
- **Glass Cards** - Frosted glass effect with blur
- **Gradient Text** - Animated gradient text effect
- **Gradient Buttons** - Primary CTA buttons with hover effects
- **Navigation** - Sticky header with mobile menu

## 📄 Pages

### Home Page (`/`)
- App icon and branding
- Feature highlights with icons
- App screenshots grid
- Call-to-action buttons for Google Play Store
- Version display

### Privacy Policy (`/privacy`)
- Comprehensive privacy policy
- Data collection details
- Security measures
- User rights and compliance
- Contact information
- Google Play Store compliant

### About Us (`/about`)
- Company mission and values
- Why we created the app
- Core principles
- How the app works
- Feature comparison table
- Team credentials
- Contact information

## 🔧 Customization

### Update App Information
Edit the following files to customize app details:

1. **Home Page** (`client/src/pages/Home.tsx`)
   - App name and tagline
   - Features list
   - Google Play Store link

2. **Privacy Policy** (`client/src/pages/Privacy.tsx`)
   - Privacy policy content
   - Contact email addresses
   - Compliance information

3. **About Us** (`client/src/pages/About.tsx`)
   - Company mission
   - Team information
   - Contact details

### Add Screenshots
1. Place screenshots in `client/public/screenshots/`
2. Update `Home.tsx` screenshot section with image references
3. See `ASSETS_GUIDE.md` for detailed instructions

### Modify Colors
Edit `client/src/index.css` to change the color scheme:

```css
:root {
  --primary: #8b5cf6;           /* Primary purple */
  --accent: #3b82f6;            /* Accent blue */
  --background: #0a0e27;        /* Dark background */
  --foreground: #e8e9f3;        /* Light text */
}
```

## 📱 Responsive Design

The website is fully responsive and optimized for:
- **Mobile:** 320px and up
- **Tablet:** 768px and up
- **Desktop:** 1024px and up

All components use Tailwind CSS utilities for responsive design.

## 🔗 Navigation

- **Home** - `/`
- **Privacy Policy** - `/privacy`
- **About Us** - `/about`
- **Google Play Store** - External link (update in Home.tsx)

## 📊 Performance

- **Framework:** React 19 with Wouter for routing
- **Styling:** Tailwind CSS 4 with custom components
- **Build Tool:** Vite
- **Bundle Size:** Minimal (static-only, no backend)
- **Loading:** Optimized for fast page loads

## ✅ Google Play Store Compliance

This website meets Google Play Store requirements:

✅ Privacy Policy page with comprehensive data protection  
✅ Clear app description and features  
✅ Mobile-responsive design  
✅ Fast loading times  
✅ No tracking or data collection  
✅ Professional appearance  
✅ Direct link to app on Play Store  

## 🚀 Deployment

### Build for Production
```bash
pnpm build
```

### Deploy to Hosting
The built files are in the `dist/` directory. Deploy to any static hosting service:
- Vercel
- Netlify
- GitHub Pages
- Firebase Hosting
- AWS S3
- Or any web server

### Environment Variables
No environment variables required for static deployment.

## 🔐 Security

- No data collection or tracking
- No external API calls
- No authentication required
- Static content only
- HTTPS recommended for deployment

## 📝 License

This website is proprietary to Kgn Solution.

## 📞 Support

For questions or issues:
- **Email:** support@photovault.app
- **Feedback:** feedback@photovault.app
- **Privacy:** privacy@photovault.app

## 🎯 Next Steps

1. **Add Screenshots**
   - Follow `ASSETS_GUIDE.md` for detailed instructions
   - Place screenshots in `client/public/screenshots/`

2. **Update Contact Information**
   - Verify email addresses in footer and pages
   - Update Google Play Store link

3. **Test Thoroughly**
   - Test on mobile devices
   - Verify all links work
   - Check responsive design

4. **Deploy**
   - Build with `pnpm build`
   - Deploy to your hosting platform
   - Submit URL to Google Play Store

## 📚 Additional Resources

- [Tailwind CSS Documentation](https://tailwindcss.com)
- [React Documentation](https://react.dev)
- [Wouter Router Documentation](https://github.com/molefrog/wouter)
- [Google Play Store Guidelines](https://play.google.com/console/about/help-center/)

---

**Developed by:** Kgn Solution  
**App Name:** Photo Lock Fingerprint  
**Last Updated:** January 2024
