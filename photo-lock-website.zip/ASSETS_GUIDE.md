# Photo Lock Fingerprint Website - Assets Guide

## Overview

This guide explains how to replace placeholder assets with real images from your Google Play Store app listing.

---

## Image Assets Required

### 1. App Icon
**Location:** Currently using emoji placeholder (🔒)  
**Size:** 192x192px (minimum)  
**Format:** PNG with transparency  
**Replacement Instructions:**
- Use your app's official icon from Google Play Store
- Ensure it matches your app branding
- The icon appears in the hero section on the Home page

### 2. App Screenshots
**Location:** Home page - Screenshots section  
**Quantity:** 3 screenshots (can be extended to more)  
**Size:** 1080x1920px (9:16 aspect ratio for mobile)  
**Format:** PNG or JPG  
**Replacement Instructions:**

In `client/src/pages/Home.tsx`, find the screenshots section:

```tsx
const screenshots = [
  { id: 1, alt: "App Lock Screen" },
  { id: 2, alt: "Gallery View" },
  { id: 3, alt: "Settings Screen" },
];
```

Replace the placeholder divs with actual images. Currently, the code shows:
```tsx
<div className="glass rounded-xl overflow-hidden aspect-[9/16] flex items-center justify-center">
  {/* Replace with Play Store screenshot */}
  <div className="w-full h-full bg-gradient-to-br from-purple-500/10 to-blue-500/10 flex items-center justify-center">
    ...
  </div>
</div>
```

Update to:
```tsx
<img
  src="/screenshots/screenshot{id}.png"
  alt={screenshot.alt}
  className="w-full h-full object-cover"
/>
```

---

## How to Add Images to the Project

### Step 1: Prepare Your Images
- Export screenshots from your Google Play Store app listing
- Ensure they are in PNG format (recommended) or JPG
- Verify dimensions: 1080x1920px for screenshots

### Step 2: Add to Public Folder
1. Place images in: `client/public/screenshots/`
2. Create the `screenshots` folder if it doesn't exist
3. Name files consistently: `screenshot1.png`, `screenshot2.png`, `screenshot3.png`

### Step 3: Update Component Code
Edit `client/src/pages/Home.tsx` and replace the placeholder screenshot section with actual image elements.

---

## Current Placeholder Elements

### Home Page (`client/src/pages/Home.tsx`)

1. **App Icon Display**
   - Location: Hero section, right side
   - Current: Emoji placeholder (🔒)
   - Recommendation: Replace with actual app icon

2. **Screenshots Grid**
   - Location: "App Screenshots" section
   - Current: Placeholder divs with gradient backgrounds
   - Recommendation: Replace with actual Play Store screenshots

### Privacy Policy Page (`client/src/pages/Privacy.tsx`)
- No image placeholders (text-only content)
- All content ready for Google Play Store compliance

### About Us Page (`client/src/pages/About.tsx`)
- No image placeholders (text-only content)
- All content ready for deployment

---

## Design System Colors

The website uses a dark glassmorphism theme with the following color palette:

| Element | Color | Usage |
|---------|-------|-------|
| Primary Gradient | Purple (#8b5cf6) to Blue (#3b82f6) | Buttons, text accents |
| Background | Dark Navy (#0a0e27) | Page background |
| Glass Effect | RGBA(30, 27, 75, 0.4) | Card backgrounds |
| Text Primary | Light (#e8e9f3) | Main text |
| Text Secondary | Light/60% opacity | Secondary text |
| Accent | Blue (#3b82f6) | Interactive elements |

---

## Typography

The website uses Google Fonts:

- **Display Font:** Sora (weights: 400, 500, 600, 700)
- **Monospace Font:** Space Mono (weights: 400, 700)

These fonts are loaded in `client/index.html` and configured in `client/src/index.css`.

---

## Responsive Design

The website is fully responsive and tested for:
- Mobile devices (320px and up)
- Tablets (768px and up)
- Desktop (1024px and up)

All images should be optimized for web to ensure fast loading times.

---

## Google Play Store Compliance

✅ **Compliant Features:**
- Privacy Policy page with comprehensive data protection information
- About Us page with company mission and values
- Clear app description and features
- Direct link to Google Play Store
- Mobile-responsive design
- Fast loading (HTML + CSS only)
- No tracking or analytics collection

---

## File Structure

```
photo-lock-website/
├── client/
│   ├── public/
│   │   └── screenshots/          ← Add your screenshots here
│   │       ├── screenshot1.png
│   │       ├── screenshot2.png
│   │       └── screenshot3.png
│   ├── src/
│   │   ├── components/
│   │   │   ├── Navigation.tsx
│   │   │   └── Footer.tsx
│   │   ├── pages/
│   │   │   ├── Home.tsx
│   │   │   ├── Privacy.tsx
│   │   │   ├── About.tsx
│   │   │   └── NotFound.tsx
│   │   ├── App.tsx
│   │   └── index.css
│   └── index.html
├── server/
│   └── index.ts
└── package.json
```

---

## Deployment Checklist

Before submitting to Google Play Store:

- [ ] Replace app icon placeholder with actual icon
- [ ] Add all 3+ screenshots to `client/public/screenshots/`
- [ ] Update screenshot references in `Home.tsx`
- [ ] Test all links (Privacy Policy, About Us, Google Play Store link)
- [ ] Verify mobile responsiveness on actual devices
- [ ] Test on different Android versions
- [ ] Verify all text content is accurate and up-to-date
- [ ] Check for broken links or missing images
- [ ] Optimize images for web (compression)

---

## Quick Start

1. **Install dependencies:**
   ```bash
   pnpm install
   ```

2. **Start development server:**
   ```bash
   pnpm dev
   ```

3. **Build for production:**
   ```bash
   pnpm build
   ```

4. **Preview production build:**
   ```bash
   pnpm preview
   ```

---

## Support & Questions

For questions about the website structure or asset placement, refer to the component files:
- `client/src/pages/Home.tsx` - Home page with screenshots section
- `client/src/components/Navigation.tsx` - Header navigation
- `client/src/components/Footer.tsx` - Footer with contact info

All components are fully documented with inline comments explaining the design and functionality.

---

## Notes

- The website uses a static-only template (no backend required)
- All styling is done with Tailwind CSS and custom CSS classes
- The glassmorphism effect is achieved through backdrop blur and transparent backgrounds
- The gradient text effect is applied using CSS gradients
- Mobile menu is fully functional and responsive
